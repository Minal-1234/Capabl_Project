
# Spaceship Titanic Rescue

## Introduction
The Spaceship Titanic Rescue Mission is a project which makes use of machine learning model to predict the which passengers where transported to another dimensions during the Spaceship Titanic's collision with a spacetime anomaly and which were not transported. 
This will help the rescue crew to the passengers which need to be rescued. The project uses various features to determine the outcome. It uses python libraries to analyse the datasets and perform required processing to set a machine learning model.




## Prerequisites

**The system must have**

    1] Python3
    2] Suitable notebook environment (e.g. Jupyter Notebook)

**Packages and Libraries used**

    1] Pandas
    2] Numpy
    3] Matplotlib
    4] Seaborn
    5] Sklearn
    6] Warnings
    7] Lazypredict
    8] Lightgbm

**Datasets**

Link for the train and test datasets.

https://drive.google.com/drive/folders/1APRUFcnGNcQVqPR20ZfhT-N-nXHj9qIr
## Project Detailing

### Step 1 - Importing Required Libraries
    In this step all the required libraries and modules are imported.
    It also sets up the number of columns of dataframe to be displayed in the output.

### Step 2 - Loading the Dataset
    The dataset is loaded into a pandas dataframe called train and test.
    The train data is for modelling and test data is the data of which  the results are to be predicted.

### Step 3 - EDA
    Exploratory data analysis is performed to identify missing values, 
    important features, draw patterns and discover important relationship between various features.
    It proceeds as follows:

**1]Gaining information of the dataset**

    Uses method such as '.head()' ,'.info()', etc.

**2] Data Preprocessing**

    Analysing and rocessing the data for making it fit for modelling.
    It involves:

***1] Categorization of Columns : categorical, numerical and cardinal***

        It helps to which column requires what type of encoding such as label encoding or one hot encoding.
        Also it helps us identify the number of columns of different datatype.

***2] Threshold and outlier detection***

        The outlier_thresholds function is designed to calculate the lower and upper limits for detecting outliers in a specified column of 
a DataFrame.
        Here the interquartile range (IQR) method is used, but with customizable quantiles.

***3] Missing value detection and filling places with missing values***

        This detects missing values in the dataset.
        The names of the columns having missing values will be displayed along with number of missing values in each column and the ratio of missing values.
        The Missing values are filled mostly using mode.

***4] Category variable analysis according to target***

        The dataframe is taken as input the required categorical column is sumarized and if required a plot is created.
        It compares each value of the categorical column to target to check if target for a particular value is true or false.
        It also gives the ratio for it.

***5] Correlation***

        It gives the measure of how strongly a feature is related to another feature.
        It also gives various categories and their count present in a column and their realtionship with target.

***6] Categorical column to target analysis according to target***
        Examining how the categories within categorical variables are related to the target variable. 

### Step 4 - Feature Engineering
    Deciding which features can most affect the target colum and changing and maintaning features accordingly.
    It includes:

**1] Combining features as required**

    Combining features from cryosleep column with cabin number to check for the new column. 
    Also new column have categories such as if cryosleep is true then unique cabin number and same applies to cryosleep is False.
    Combining feature from cryosleep and destination in same way as above.
    Combinig features from cryosleep and age.
    Combining feature from VIP and Total Spent.
    Splitting passemger ID to create columns as solo and family.

**1] Encoding**

    A correlation heatmap is created.
    Binary columns are identified and listed
    Binary columns are encoded using label encoding.
    Categorical columns are identified and listed.
    Categorical columns with more than two category but less than twenty five category are encoded using one hot encoding.

**3] Discarding Unnecessary Columns**
    
    Column such as 'PassengerID' and 'Name' are dropped since they are unnecessary.

**4] Scaling for Normalization**
    Scales the data in a range.
    Uses RobustScaler for scaling the numerical data.

### Step 5 - Modelling
    Fitting the training data in a suitable machine learning model to make predictions

**1] Select the model**
    
    We have used lazy predict to find out the most suitable model for this data.

**2] Train - Test Splitting**
    Splitting the train data for training and testing.

**3] Fitting into Model**
    The data is further fitted into LGBMClassifier since it has the highest accuracy score.
    The prediction is done using test(the data to be actually predicted) and accuracy is checked.

***1] Cross Validation***
    The cross validation here divides the dataset into 5 parts and evaluates it.
    It uses Accuracy, Precision, Recall, F1 and ROC_AUC.

### Step 6 - Hyperparameter Tuning
    1] This sets the parameters required for fine tuning the model to increase performance.
    2] The parameters used are learning_rate, n_estimators and colsample_bytree.
    3] Here GridSearchCV is used for tuning and cross validation folds are kept 10 along with n_jobs=-1(which means all the processes will run parallely).
    4] Fit the model along with data in the parameters to tune the model.
    5] Plot importance of each feature in the LGBM Model.
    6] Again check for the accuracy, precision, recall, F1 Score and ROC_AUC.
    7] Predict the final results uding this model.

### Step 7 - Saving the results
    Converting the result in dataframe format to csv format and save it in an appropriate location.
## Execution

Below are steps to execute the file:

1] Open suitable notebook environment (e.g. Jupyter notebook).
2] Import the file.
3] Open the file in the environment.
4] Run the cells and it will provide the required results.